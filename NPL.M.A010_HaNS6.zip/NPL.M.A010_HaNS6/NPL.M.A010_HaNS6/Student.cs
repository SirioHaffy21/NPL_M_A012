﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPL.M.A010_HaNS6
{
    public class Student
    {
        public Student()
        {

        }

        public Student(string name, string @class, string gender, DateTime entryDate, int age, string address, string relationship = "Single", double mark = 0, string grade = "F")
        {
            Name = name;
            Class = @class;
            Gender = gender;
            Relationship = relationship;
            EntryDate = entryDate;
            Age = age;
            Address = address;
            Mark = mark;
            Grade = grade;
        }

        public Student(string name, string @class, string gender, string relationship, DateTime entryDate, int age, string address, double mark, string grade)
        {
            Name = name;
            Class = @class;
            Gender = gender;
            Relationship = relationship;
            EntryDate = entryDate;
            Age = age;
            Address = address;
            Mark = mark;
            Grade = grade;
        }


        public string Name { get; set; }

        public string Class { get; set; }

        public string Gender { get; set; }

        public string Relationship { get; set; }

        public DateTime EntryDate { get; set; }

        public int Age { get; set; }

        public string Address { get; set; }

        public double Mark { get; set; }

        public string Grade { get; set; }

        public virtual string gradePoint()
        {
            if (Mark == 0)
            {
                return "F";
            }
            else if (Mark > 1.0 && Mark < 2.0)
            {
                return "D";
            }
            else if (Mark > 2.0 && Mark <= 2.2)
            {
                return "C";
            }
            else if (Mark >= 2.3 && Mark <= 2.7)
            {
                return "C+";
            }
            else if (Mark > 2.7 && Mark < 3.0)
            {
                return "B-";
            }
            else if (Mark >= 3.0 && Mark < 3.3)
            {
                return "B";
            }
            else if (Mark >= 3.3 && Mark < 3.7)
            {
                return "B+";
            }
            else if (Mark >= 3.7 && Mark < 4.0)
            {
                return "A-";
            }
            else if (Mark == 4.0)
            {
                return "A";
            }
            return Grade;
        }

        public override string ToString()
        {
            return string.Format("{0, -20}{1, 20}{2, 20}{3, 20}{4, 20}{5, 20}", Name, Class, Gender, Relationship, Age, gradePoint());
        }
    }
}
