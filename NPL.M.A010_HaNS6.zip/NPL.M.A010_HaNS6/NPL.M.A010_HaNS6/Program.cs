﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPL.M.A010_HaNS6
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            List<Student> students = new List<Student>();
            Student student = new Student();
            Student studentPara = new Student();
            
            Student student1st = new Student("Ha", "Net 06", "Male", DateTime.Now, 20, "Ha Noi",student.Relationship, 4.0, "");
            Student student2nd = new Student("Hai", "Net 07", "Male", DateTime.Now, 21, "Ha Noi", "Married", 3.2, "");
            Student student3rd = new Student("Hoa", "Test 05", "Female", DateTime.Now, 22, "Ha Noi", student.Relationship, 2.5, "");
            Student student4th = new Student(name: "Hung", @class: "Java 03", gender: "Male", entryDate: DateTime.Now, age: 21, address: "Da Nang", mark: 0, grade: "");

            students.Add(student1st);
            students.Add(student2nd);
            students.Add(student3rd);
            students.Add(student4th);

            Student studentNoPara = new Student();
            students.Add(studentNoPara);

            foreach (var item in students)
            {
                Console.WriteLine(" " + item.ToString());
            }

            Console.ReadKey();
        }
    }
}
